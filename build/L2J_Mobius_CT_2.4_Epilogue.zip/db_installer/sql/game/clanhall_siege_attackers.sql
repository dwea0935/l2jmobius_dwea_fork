CREATE TABLE IF NOT EXISTS `clanhall_siege_attackers` (
  `clanhall_id` int(3) NOT NULL DEFAULT '0',
  `attacker_id` int(10) NOT NULL DEFAULT '0'
) DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;