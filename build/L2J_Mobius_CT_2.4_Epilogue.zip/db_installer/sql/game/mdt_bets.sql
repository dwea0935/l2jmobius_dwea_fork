CREATE TABLE IF NOT EXISTS `mdt_bets` (
  `lane_id` INT(1) DEFAULT 0,
  `bet` INT DEFAULT 0,
  PRIMARY KEY (`lane_id`)
) DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

INSERT INTO `mdt_bets` VALUES
('1','0'),
('2','0'),
('3','0'),
('4','0'),
('5','0'),
('6','0'),
('7','0'),
('8','0');