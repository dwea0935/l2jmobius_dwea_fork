#!/bin/sh
java -cp ./../libs/*: org.l2jmobius.tools.DatabaseInstaller
